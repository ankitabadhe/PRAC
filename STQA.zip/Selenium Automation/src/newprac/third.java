package newprac;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class third {
public static void main(String[] args) throws InterruptedException {
System.setProperty("webdriver.chrome.driver","C:\\Users\\ankit\\Downloads\\chromedriver-win64\\chromedriver.exe");
WebDriver driver=new ChromeDriver();
driver = new ChromeDriver();
String appUrl = "https://en.wikipedia.org/wiki/Main_Page";
driver.get(appUrl);
Thread.sleep(2000);
// Click on Registration link
driver.findElement(By.xpath("//*[@id=\"pt-createaccount-2\"]/a")).click();
Thread.sleep(2000);
// Go back to Home Page
driver.navigate().back();
Thread.sleep(2000);
// Go forward to Registration page
driver.navigate().forward();
Thread.sleep(2000);
// Go back to Home page
driver.navigate().to(appUrl);
Thread.sleep(2000);
// Refresh browser
driver.navigate().refresh();
Thread.sleep(2000);
// Close browser
driver.close();
}
}
