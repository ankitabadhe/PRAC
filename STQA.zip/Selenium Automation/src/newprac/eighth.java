package newprac;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class eighth {
public static void main(String[] args) throws InterruptedException {
System.setProperty("webdriver.chrome.driver","C:\\Users\\ankit\\Downloads\\chromedriver-win64\\chromedriver.exe");
WebDriver wd=new ChromeDriver();
wd.get("https://opensource-demo.orangehrmlive.com/");
wd.findElement(By.id("txtUsername")).sendKeys("admin");//locator id
wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);//implicit wait
wd.findElement(By.name("txtPassword")).sendKeys("admin123");
wd.findElement(By.className("button")).click();//locatorclassName2
wd.findElement(By.partialLinkText("Welcome")).click();//locatorpartiallinkTex
wd.findElement(By.xpath("//*[@id=\"welcome\"]")).click();
wd.findElement(By.linkText("Logout")).click();//locator linkTex
}
}
