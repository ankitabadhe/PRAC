package newprac;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class second {
	
static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\ankit\\Downloads\\chromedriver-win64\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://www.hyrtutorials.com/p/frames-practice.html");

		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.findElement(By.id("name")).sendKeys("Hello");
		driver.switchTo().frame(driver.findElement(By.id("frm1")));
		Thread.sleep(3000);
		Select courseDD=new Select(driver.findElement(By.id("selectnav1")));
		courseDD.selectByVisibleText("Contact");
		
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		driver.findElement(By.id("name")).sendKeys(" World");
		
		driver.switchTo().frame(driver.findElement(By.id("frm2")));
		driver.findElement(By.id("firstName")).sendKeys("Yourname");
		
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		driver.findElement(By.id("name")).sendKeys("Name");

	}
}


