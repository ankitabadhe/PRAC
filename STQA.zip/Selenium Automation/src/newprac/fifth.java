package newprac;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import java.util.List;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.WebDriverWait;

public class fifth {

public static void main(String[] args) throws InterruptedException {

System.setProperty("webdriver.chrome.driver", "C:\\Users\\ankit\\Downloads\\chromedriver-win64\\chromedriver.exe");

WebDriver driver = new ChromeDriver();

String url = "https://www.hackerrank.com/auth/login";

driver.get(url);

Thread.sleep(1000);

System.out.println("HackerRank opened");

driver.findElement(By.name("username")).sendKeys("tester.stqa@gmail.com");

driver.findElement(By.cssSelector("input[type=password]")).sendKeys("tester");

driver.findElement(By.cssSelector("button.auth-button")).click();

System.out.println("Credentials Entered");

Thread.sleep(6000);


driver.findElement(

By.xpath("/html/body/div[4]/div/div/div/div/div[1]/nav/div/div[2]/ul[1]/li/div/div/div/div/input")) .sendKeys("Tower Breakers");

Thread.sleep(6000);

System.out.println("Question Searched");

driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div/div[1]/nav/div/div[2]/ul[1]/ li/div/div/div/div[2]/ul/li[8]/div/div"))

.click();

Thread.sleep(6000);

driver.findElement(By.className("profile-menu")).click();

Thread.sleep(6000);

driver.findElement(By.className("logout-button")).click();

Thread.sleep(2000);

System.out.println("Logged out");

}

} 


