package newprac;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class seventhh {
    public static void main(String[] args) {
        // Specify the path to the Microsoft Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "C:\\Users\\ankit\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        WebDriver wd = new EdgeDriver(); // Use EdgeDriver here, not ChromeDriver

        wd.get("https://opensource-demo.orangehrmlive.com");
        WebDriverWait wt = new WebDriverWait(wd, Duration.ofSeconds(30));

        wd.findElement(By.id("txtUsername")).sendKeys("Admin");
        wd.findElement(By.id("txtPassword")).sendKeys("admin123");
        wd.findElement(By.id("btnLogin")).click();

        // Wait for the "Welcome" element to be visible
        wt.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("Welcome")));
        
        wd.findElement(By.partialLinkText("Welcome")).click();
        
        // Wait for the "Logout" link to be visible
        wt.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Logout")));
        
        wd.findElement(By.linkText("Logout")).click();
        
        // Close the WebDriver
        wd.quit();
    }
}
